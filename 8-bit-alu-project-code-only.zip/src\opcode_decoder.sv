// Project: 8-bit ALU
// Author: Aiden Huang
// Date: 2026-06-02
// Description: Decodes the 3-bit opcode into one-hot operation selects.
// Sources used: Course project prompt and SystemVerilog language reference.

module opcode_decoder (
    input  logic [2:0] opcode,
    output logic       sel_add,
    output logic       sel_sub,
    output logic       sel_and,
    output logic       sel_or,
    output logic       sel_xor,
    output logic       sel_pass_a,
    output logic       sel_pass_b,
    output logic       sel_not_a
);

    always_comb begin
        sel_add    = 1'b0;
        sel_sub    = 1'b0;
        sel_and    = 1'b0;
        sel_or     = 1'b0;
        sel_xor    = 1'b0;
        sel_pass_a = 1'b0;
        sel_pass_b = 1'b0;
        sel_not_a  = 1'b0;

        unique case (opcode)
            3'b000: sel_add    = 1'b1;
            3'b001: sel_sub    = 1'b1;
            3'b010: sel_and    = 1'b1;
            3'b011: sel_or     = 1'b1;
            3'b100: sel_xor    = 1'b1;
            3'b101: sel_pass_a = 1'b1;
            3'b110: sel_pass_b = 1'b1;
            3'b111: sel_not_a  = 1'b1;
            default: sel_add   = 1'b1;
        endcase
    end

endmodule
